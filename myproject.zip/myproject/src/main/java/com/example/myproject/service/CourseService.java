package com.example.myproject.service;

import com.example.myproject.dto.AvailableCourseDTO;
import com.example.myproject.dto.CourseEnrollmentRequest;
import com.example.myproject.dto.StudentCoursesDTO;
import com.example.myproject.entity.Course;
import com.example.myproject.entity.CoursePrerequisite;
import com.example.myproject.entity.StudentCourses;
import com.example.myproject.repo.CoursePrerequisiteRepository;
import com.example.myproject.repo.CourseRepository;
import com.example.myproject.repo.StudentCoursesRepository;
import com.example.myproject.repo.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class CourseService {

    private final CourseRepository courseRepository;
    private final StudentCoursesRepository studentCoursesRepository;
    private final CoursePrerequisiteRepository coursePrerequisiteRepository;
    private final StudentRepository studentRepository;
    private final CacheManager cacheManager;

    @Autowired
    public CourseService(CourseRepository courseRepository,
                         StudentCoursesRepository studentCoursesRepository,
                         CoursePrerequisiteRepository coursePrerequisiteRepository,
                         StudentRepository studentRepository,
                         CacheManager cacheManager) {
        this.courseRepository = courseRepository;
        this.studentCoursesRepository = studentCoursesRepository;
        this.coursePrerequisiteRepository = coursePrerequisiteRepository;
        this.studentRepository = studentRepository;
        this.cacheManager = cacheManager;
    }

    @Cacheable(value = "availableCourses", key = "#rollno.concat('-').concat(#term)")
    public List<AvailableCourseDTO> getAvailableCourses(String rollno, String term) {
        List<Course> coursesInTerm = courseRepository.findByTerm(term);

        List<StudentCourses> studentCourses = studentCoursesRepository.findByStudent_RollNo(rollno);

        List<String> completedCourseCodes = studentCourses.stream()
                .map(sc -> sc.getCourse().getCourseCode())
                .collect(Collectors.toList());

        List<AvailableCourseDTO> courseDetails = new ArrayList<>();

        for (Course course : coursesInTerm) {
            if (completedCourseCodes.contains(course.getCourseCode())) {
                continue;
            }

            List<CoursePrerequisite> prerequisites = coursePrerequisiteRepository.findByCourse_CourseCode(course.getCourseCode());

            List<String> prerequisiteCodes = prerequisites.stream()
                    .map(prerequisite -> prerequisite.getPrerequisite().getCourseCode())
                    .collect(Collectors.toList());

            boolean prerequisitesMet = prerequisiteCodes.isEmpty() || completedCourseCodes.containsAll(prerequisiteCodes);

            if (prerequisitesMet) {
                AvailableCourseDTO courseDTO = new AvailableCourseDTO();
                courseDTO.setName(course.getName());
                courseDTO.setCourseCode(course.getCourseCode());
                courseDTO.setProfessor(course.getFaculty());
                courseDTO.setCredits(course.getCredit());
                courseDTO.setPrerequisites(prerequisiteCodes);

                courseDetails.add(courseDTO);
            }
        }

        return courseDetails;
    }

    @CacheEvict(value = "availableCourses", key = "#request.rollno.concat('-').concat(#request.term)")
    public Map<String, String> enrollStudent(CourseEnrollmentRequest request) {
        String rollno = request.getRollno();
        List<String> selectedCourses = request.getSelectedCourses();

        if (selectedCourses == null || selectedCourses.isEmpty()) {
            throw new IllegalArgumentException("No courses selected for enrollment.");
        }

        String cacheKey = rollno + "-" + "Fall";
        List<AvailableCourseDTO> availableCourses = cacheManager
                .getCache("availableCourses")
                .get(cacheKey, List.class);

        if (availableCourses == null || availableCourses.isEmpty()) {
            throw new IllegalStateException("Available courses data not found. Please fetch available courses first.");
        }

        List<String> availableCourseCodes = availableCourses.stream()
                .map(AvailableCourseDTO::getCourseCode)
                .collect(Collectors.toList());

        if (!availableCourseCodes.containsAll(selectedCourses)) {
            throw new IllegalArgumentException("Some selected courses are not available.");
        }

        if (selectedCourses.size() < 4 || selectedCourses.size() > 6) {
            throw new IllegalArgumentException("You must select between 4 and 6 unique courses.");
        }

        if (new HashSet<>(selectedCourses).size() != selectedCourses.size()) {
            throw new IllegalArgumentException("Duplicate courses found in the selection.");
        }

        for (String courseId : selectedCourses) {
            StudentCoursesDTO studentCoursesDTO = new StudentCoursesDTO();
            studentCoursesDTO.setStudentId(rollno);
            studentCoursesDTO.setCourseId(courseId);
            studentCoursesDTO.setGradeId("Enrolled");

            enrollStudentInCourse(studentCoursesDTO);
        }

        return Map.of("message", "Student enrollment initiated for all courses.");
    }

    public void enrollStudentInCourse(StudentCoursesDTO studentCoursesDTO) {
        var student = studentRepository.findByRollNo(studentCoursesDTO.getStudentId())
                .orElseThrow(() -> new IllegalArgumentException("Student not found with roll number: " + studentCoursesDTO.getStudentId()));

        var course = courseRepository.findByCourseCode(studentCoursesDTO.getCourseId())
                .orElseThrow(() -> new IllegalArgumentException("Course not found with code: " + studentCoursesDTO.getCourseId()));

        StudentCourses studentCourses = new StudentCourses();
        studentCourses.setStudent(student);
        studentCourses.setCourse(course);
        studentCourses.setGradeId(studentCoursesDTO.getGradeId());

        studentCoursesRepository.save(studentCourses);
    }
}
